//
//  objcFramework.h
//  objcFramework
//
//  Created by Darius Jankauskas on 01/07/2020.
//

#import <Foundation/Foundation.h>

//! Project version number for objcFramework.
FOUNDATION_EXPORT double objcFrameworkVersionNumber;

//! Project version string for objcFramework.
FOUNDATION_EXPORT const unsigned char objcFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <objcFramework/PublicHeader.h>

#import <objcFramework/FramyO.h>
